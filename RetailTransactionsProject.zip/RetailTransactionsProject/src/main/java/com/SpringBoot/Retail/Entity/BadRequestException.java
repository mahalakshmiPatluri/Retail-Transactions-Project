package com.SpringBoot.Retail.Entity;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

//To display the bad request customized exception
@ResponseStatus(HttpStatus.BAD_REQUEST)
public final class BadRequestException extends RuntimeException {
	
	private static final long serialVersionUID = 7445888121198843350L;

	public BadRequestException(final String message) {
		super(message);
	}
}