package com.SpringBoot.Retail.Controller;

import java.util.Date;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.Retail.Entity.UserRegistration;
import com.SpringBoot.Retail.Service.UserRegistrationService;
import com.SpringBoot.Retail.Utility.Utility;

@RestController
@RequestMapping(path = "/registration") // URI should not be case sensitive
public class UserRegistrationController {

	private UserRegistrationService userRegistrationService;

	public UserRegistrationController(UserRegistrationService userRegistrationService) {
		this.userRegistrationService = userRegistrationService;
	}

	@PostMapping("/user")
	public ResponseEntity<Object> addUser(@RequestBody UserRegistration userReg) {
		return processUserRegistration(userReg);
	}

	private ResponseEntity<Object> processUserRegistration(UserRegistration userReg) {
		boolean isValidEmail = validateEmail(userReg.getEmail());
		boolean isValidMobile = validateMobileNumber(userReg.getMobile());

		if (isValidEmail && isValidMobile) {
			userRegistrationService.save(userReg);
			userReg.setEmail(Utility.getMaskedCardNumber(userReg.getEmail()));
			// userReg.setMobile(Long.getLong(Utility.getMaskedCardNumber(String.valueOf(userReg.getMobile()))));
			return new ResponseEntity<Object>(userReg, HttpStatus.OK);
		} else {
			UserRegistrationFailureResponse failureRespose = new UserRegistrationFailureResponse();
			failureRespose.setTimestamp(new Date());
			failureRespose.setErrorCode(500);
			failureRespose.setPath("/regitration/user");
			if (!isValidMobile) {
				failureRespose.setMessage("Invalid Mobile Number!");
			}
			if (!isValidEmail) {
				failureRespose.setMessage("Invalid Email Format!");
			}

			return new ResponseEntity<Object>(failureRespose, HttpStatus.OK);
		}
	}

	/*
	 * private boolean validateUserRegistrationRequest(UserRegistration userReg) {
	 * boolean result; result = validateEmail(userReg.getEmail()); result =
	 * validateMobileNumber(userReg.getMobile()); return result; }
	 */

	private boolean validateEmail(String email) {
		String regex = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
		return email.matches(regex);
	}

	private boolean validateMobileNumber(long mobile) {
		int length = String.valueOf(mobile).length();
		if (length != 10) {
			return false;
		}
		return true;
	}

	@GetMapping("/users")
	public List<UserRegistration> getAllUsers() {
		return userRegistrationService.getAllUsers();
	}

	@PutMapping("/user")
	public Object updateUser(@RequestBody UserRegistration userReg) {
		userRegistrationService.saveOrUpdate(userReg);
		return new ResponseEntity<Object>(HttpStatus.ACCEPTED);
	}

	@DeleteMapping("/user/{id}")
	public Object deleteUser(@PathVariable("id") int id) {
		ResponseEntity<UserRegistrationFailureResponse> failureResponse = ResponseEntity.status(HttpStatus.OK)
				.body(new UserRegistrationFailureResponse(new Date(), 200, "User with this ID Number not available",
						"/registration/user"));
		try {
			userRegistrationService.deleteUserById(id);
			return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {

			return failureResponse;
		}
	}
}
