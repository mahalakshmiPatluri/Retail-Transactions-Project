package com.SpringBoot.Retail.Entity;

public class MonthlyData {

	public String month;
	public int noOfTransactions;
	public float totalAmount;
	public float totalRewardsPoints;

	public int getNoOfTransactions() {
		return noOfTransactions;
	}

	public void setNoOfTransactions(int noOfTransactions) {
		this.noOfTransactions = noOfTransactions;
	}

	public float getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}

	public float getTotalRewardsPoints() {
		return totalRewardsPoints;
	}

	public void setTotalRewardsPoints(float points) {
		this.totalRewardsPoints = points;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public MonthlyData() {
	}

}
