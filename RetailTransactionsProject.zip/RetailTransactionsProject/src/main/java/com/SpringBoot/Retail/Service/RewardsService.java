package com.SpringBoot.Retail.Service;

import java.time.Month;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.Retail.Entity.MonthlyData;
import com.SpringBoot.Retail.Entity.Rewards;
import com.SpringBoot.Retail.Entity.RewardsMonth;
import com.SpringBoot.Retail.Entity.Transaction;
import com.SpringBoot.Retail.Repository.TransactionRepository;
import com.SpringBoot.Retail.Utility.Utility;

@Service
public class RewardsService {

	TransactionRepository transactionRepo;

	public RewardsService(TransactionRepository transactionRepo) {
		this.transactionRepo = transactionRepo;
	}

	public Map<List<MonthlyData>, MonthlyData> getUsersById(int id) {

		List<Object[]> listOfTransactions = transactionRepo.getListOfTransactions(id);

		ArrayList<MonthlyData> listMonthly = new ArrayList<MonthlyData>();
		Map<List<MonthlyData>, MonthlyData> map1 = new LinkedHashMap<>();
		MonthlyData res1 = new MonthlyData();

		for (Object[] transaction : listOfTransactions) {
			MonthlyData rewardEx1 = new MonthlyData();
			rewardEx1.setMonth((String) transaction[1]);

			listMonthly.add(rewardEx1);

			res1.setMonth((String) transaction[1]);
			res1.setTotalAmount((float) transaction[4]);

			map1.put(listMonthly, res1);

			System.out.println("MAP VALUE:" + map1);
		}

		return map1;

		/*
		 * ArrayList<Rewards> al = new ArrayList<Rewards>();
		 * 
		 * List<Object[]> listOfTransactions =
		 * transactionRepo.getListOfTransactions(id); Map<List<Rewards>, MonthlyData>
		 * map = new LinkedHashMap<>(); MonthlyData res = new MonthlyData();
		 * 
		 * for (Object[] transaction : listOfTransactions) { Rewards rewardEx = new
		 * Rewards();
		 * 
		 * rewardEx.setId((int) transaction[0]); rewardEx.setMonth((String)
		 * transaction[1]); rewardEx.setYear((int) transaction[2]);
		 * rewardEx.setTransRefNo((int) transaction[3]); rewardEx.setTransAmt((float)
		 * transaction[4]); rewardEx.setTransType((String) transaction[5]);
		 * rewardEx.setCardNumber((String) transaction[6]); rewardEx.setCvv((String)
		 * transaction[7]);
		 * 
		 * al.add(rewardEx);
		 * 
		 * map.put(al, res);
		 * 
		 * }
		 */

	}
}
