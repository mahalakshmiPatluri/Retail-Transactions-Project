package com.SpringBoot.Retail.Entity;

import java.time.Month;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class Rewards {
	private int id;
	private String month;
	private int year;
	private int transRefNo;
	private float transAmt;
	private String transType;
	private String cardNumber;
	private String cvv;

	public Rewards() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getTransRefNo() {
		return transRefNo;
	}

	public void setTransRefNo(int transRefNo) {
		this.transRefNo = transRefNo;
	}

	public float getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(float transAmt) {
		this.transAmt = transAmt;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	@Override
	public String toString() {
		return "Rewards [id=" + id + ", month=" + month + ", year=" + year + ", transRefNo=" + transRefNo
				+ ", transAmt=" + transAmt + ", transType=" + transType + ", cardNumber=" + cardNumber + ", cvv=" + cvv
				+ ", getId()=" + getId() + ", getMonth()=" + getMonth() + ", getYear()=" + getYear()
				+ ", getTransRefNo()=" + getTransRefNo() + ", getTransAmt()=" + getTransAmt() + ", getTransType()="
				+ getTransType() + ", getCardNumber()=" + getCardNumber() + ", getCvv()=" + getCvv() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
