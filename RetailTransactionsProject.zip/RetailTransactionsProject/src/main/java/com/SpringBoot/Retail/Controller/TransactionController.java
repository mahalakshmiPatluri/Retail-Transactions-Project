package com.SpringBoot.Retail.Controller;

import java.util.Date;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.Retail.Entity.Transaction;
import com.SpringBoot.Retail.Service.TransactionService;
import com.SpringBoot.Retail.Service.UserRegistrationService;

@RestController
//@RequestMapping(path = "/transaction")
public class TransactionController {
	TransactionService transactionService;

	RewardsController rewardsController;

	UserRegistrationService userRegistrationService;

	/** */
	public TransactionController(TransactionService transactionService, RewardsController rewardsController,
			UserRegistrationService userRegistrationService) {
		// super();
		this.transactionService = transactionService;
		this.rewardsController = rewardsController;
		this.userRegistrationService = userRegistrationService;
	}

	/** */
	@PostMapping("/transactions")
	public ResponseEntity<Object> addTransaction(@RequestBody final Transaction transaction) {
		return processTransaction(transaction);
	}

	private ResponseEntity<Object> processTransaction(final Transaction transaction) {
		final boolean isValid = validateTransactionRequest(transaction);
		if (isValid) {
			final TransactionFailureResponse failureRespose = new TransactionFailureResponse(new Date(),
					HttpStatus.BAD_REQUEST.value(), "Failed due to Invalid request information", "/transactions");
			return new ResponseEntity<Object>(failureRespose, HttpStatus.OK);
		} else {
			transactionService.save(transaction);
			return new ResponseEntity<Object>(transaction, HttpStatus.OK);
		}
	}

	/** */
	private boolean validateTransactionRequest(final Transaction transaction) {
		final int cardNumberLength = String.valueOf(transaction.getCardNumber()).length();
		boolean result = true;
		if (cardNumberLength != 16 && cardNumberLength != 15) {
			result = true;
		} else {
			result = false;
		}
		return result;
	}

	/** */

	@GetMapping("/transactions")
	public List<Transaction> getAllTransactions() {
		return transactionService.getAllTransactionDetails();
	}

	/** */
	@PutMapping("/transactions")
	public Object updateTransaction(@RequestBody final Transaction transaction) {
		transactionService.saveOrUpdate(transaction);
		return new ResponseEntity<Object>(HttpStatus.ACCEPTED);

	}

	/** */
	@DeleteMapping("/transaction/{transRefNo}")
	public Object deleteTransaction(@PathVariable("transRefNo") final int transRefNo) {

		try {
			transactionService.deleteTransactionById(transRefNo);
			return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			ResponseEntity<UserRegistrationFailureResponse> failureResponse = ResponseEntity.status(HttpStatus.OK).body(
					new UserRegistrationFailureResponse(new Date(), 200, e.getMessage(), "transaction/transaction"));
			return failureResponse;
		}
	}
}
