package com.SpringBoot.Retail.Service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.SpringBoot.Retail.Entity.Transaction;
import com.SpringBoot.Retail.Repository.TransactionRepository;
import com.SpringBoot.Retail.Repository.TransactionRepositoryInteger;
/***/
@Service
public class TransactionService {
	TransactionRepository transactionRepo;

	TransactionRepositoryInteger transactionRepository;
	

	
/***/
	public TransactionService(final TransactionRepository transactionRepo,
			final TransactionRepositoryInteger transactionRepository) {
		this.transactionRepo = transactionRepo;
		this.transactionRepository = transactionRepository;
	}
/***/
	public Transaction save(final Transaction transaction) {
		return transactionRepo.save(transaction);
	}
/***/
	public  List<Transaction> getUserById(final int id) {
		return transactionRepo.findById(id);
	}
/***/
	public  List<Transaction> getAllTransactions(int id) {
		final List<Transaction> transaction = new ArrayList<Transaction>();
		transactionRepo.findAll().forEach(transactions -> transaction.add(transactions));
		//List<Transaction> findAll = (List<Transaction>) transactionRepo.findAll();
		return transaction;
	}
/***/
	
	public  List<Transaction> getAllTransactionDetails() {
		final List<Transaction> transaction = new ArrayList<Transaction>();
		transactionRepo.findAll().forEach(transactions -> transaction.add(transactions));
		return transaction;
	}
	
	public  Transaction saveOrUpdate(final Transaction transaction) {
		return transactionRepo.save(transaction);
	}
/***/
	public  void deleteTransactionById(final int transRefNo) {
		transactionRepository.deleteById((int) transRefNo);
		
	}
}
