package com.SpringBoot.Retail.Entity;

public class RewardsMonth {
	private String month;

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public RewardsMonth(String month) {
		this.month = month;
	}



}
