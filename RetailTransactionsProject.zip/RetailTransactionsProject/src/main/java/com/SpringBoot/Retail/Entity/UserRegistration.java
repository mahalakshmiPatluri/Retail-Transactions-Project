package com.SpringBoot.Retail.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity	
@Table
public class UserRegistration {
	@Id
	@Column
	private long id;
	@Column
	private String userName;
	@Column
	private long mobile;
	@Column
	private String email;
	@Column
	/** UserAddress */
	private String userAddress;

	public long getId() {
		return id;
	}

	public void setId(final long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(final String userName) {
		this.userName = userName;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(final long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(final String userAddress) {
		this.userAddress = userAddress;
	}

	@Override
	public String toString() {
		return "UserRegistration [id=" + id + ", userName=" + userName + ", mobile=" + mobile + ", email=" + email
				+ ", userAddress=" + userAddress + ", getId()=" + getId() + ", getUserName()=" + getUserName()
				+ ", getMobile()=" + getMobile() + ", getEmail()=" + getEmail() + ", getUserAddress()="
				+ getUserAddress() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
/** */
	public UserRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserRegistration(final long id, final String userName, final long mobile, final String email,
			final String userAddress) {
		super();
		this.id = id;
		this.userName = userName;
		this.mobile = mobile;
		this.email = email;
		this.userAddress = userAddress;
	}

}
