package com.SpringBoot.Retail.Repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.SpringBoot.Retail.Entity.UserRegistration;

/** User Registration Repository*/
@Repository
public interface UserRegistrationRepository extends CrudRepository<UserRegistration, Long> {
	/** To find a user by ID*/
	Optional<UserRegistration> findById(long id);

	/**To find a user by mobile number */
	Optional<UserRegistration> findByMobile(long mobile);

}
