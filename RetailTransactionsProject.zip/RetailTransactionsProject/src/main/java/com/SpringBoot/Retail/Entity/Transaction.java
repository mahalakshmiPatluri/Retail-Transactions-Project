package com.SpringBoot.Retail.Entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Transaction")
/**Transaction Entity Class */
public class Transaction {
	@Id
	@Column
	private int transRefNo;
	@Column
	private float transAmt;
	@Column
	private String transType;

	@Column
	private int id;
	@Column
	private Date transDate;
	@Column
	private String cardNumber;
	@Column
	private String cvv;

	public int getTransRefNo() {
		return transRefNo;
	}

	public final void setTransRefNo(final int transRefNo) {
		this.transRefNo = transRefNo;
	}

	public float getTransAmt() {
		return transAmt;
	}

	public final void setTransAmt(final float transAmt) {
		this.transAmt = transAmt;
	}

	public String getTransType() {
		return transType;
	}

	public final void setTransType(final String transType) {
		this.transType = transType;
	}

	public int getId() {
		return id;
	}

	public final void setId(final int id) {
		this.id = id;
	}

	public Date getTransDate() {
		return transDate;
	}

	public final void setTransDate(final Date transDate) {
		this.transDate = transDate;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public final void setCardNumber(final String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCvv() {
		return cvv;
	}

	public final void setCvv(final String cvv) {
		this.cvv = cvv;
	}

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Transaction(int transRefNo, float transAmt, String transType, int id, Date transDate, String cardNumber,
			String cvv) {
		super();
		this.transRefNo = transRefNo;
		this.transAmt = transAmt;
		this.transType = transType;
		this.id = id;
		this.transDate = transDate;
		this.cardNumber = cardNumber;
		this.cvv = cvv;
	}

	@Override
	public String toString() {
		return "Transaction [transRefNo=" + transRefNo + ", transAmt=" + transAmt + ", transType=" + transType + ", id="
				+ id + ", transDate=" + transDate + ", cardNumber=" + cardNumber + ", cvv=" + cvv + ", getTransRefNo()="
				+ getTransRefNo() + ", getTransAmt()=" + getTransAmt() + ", getTransType()=" + getTransType()
				+ ", getId()=" + getId() + ", getTransDate()=" + getTransDate() + ", getCardNumber()=" + getCardNumber()
				+ ", getCvv()=" + getCvv() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

}
