/*
 * package com.SpringBoot.Retail.Repository;
 * 
 * import org.springframework.data.jpa.repository.Query; import
 * org.springframework.data.repository.CrudRepository; import
 * org.springframework.stereotype.Repository;
 * 
 * import com.SpringBoot.Retail.Entity.Rewards;
 * 
 *//** */
/*
 * //@Repository public interface RewardsRepository extends
 * CrudRepository<Rewards, Integer> {
 *//** *//*
			 * // void save(UserRegistration userReg);
			 * 
			 * // @Query("SELECT id from TRANSACTION") //@
			 * Query("SELECT id,transDate,transRefNo,transAmt,transType,cardNumber FROM Transaction WHERE id =:id"
			 * ) //Rewards getListOfTransactions(int id);
			 * 
			 * 
			 * 
			 * 
			 * }
			 */