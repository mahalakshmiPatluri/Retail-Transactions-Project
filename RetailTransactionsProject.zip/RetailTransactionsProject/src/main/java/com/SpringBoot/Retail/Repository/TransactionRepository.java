package com.SpringBoot.Retail.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.SpringBoot.Retail.Entity.Transaction;

/** */
@Repository
public interface TransactionRepository extends CrudRepository<Transaction, String> {
	/** */
	List<Transaction> findById(int id);

//	@Query("select tx.id,month(tx.transDate) as month,tx.transRefNo,tx.transAmt,tx.transType,tx.cardNumber,tx.cvv from Transaction tx where tx.id =:id")
	@Query("select tx.id,MONTHNAME(tx.transDate) as month,YEAR (tx.transDate) as year,tx.transRefNo,tx.transAmt,tx.transType,tx.cardNumber,tx.cvv from Transaction tx where tx.id =:id GROUP BY tx.transDate,tx.transRefNo")
	List<Object[]> getListOfTransactions(int id);  
	

}
