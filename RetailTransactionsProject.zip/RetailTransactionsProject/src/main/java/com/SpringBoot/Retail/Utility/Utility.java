package com.SpringBoot.Retail.Utility;

import org.springframework.util.StringUtils;

import com.SpringBoot.Retail.Entity.Rewards;
import com.SpringBoot.Retail.Entity.Transaction;

/** */
public class Utility {
	/** */
	public static String getMaskedCardNumber(final String cardNumber) {
		if (StringUtils.isEmpty(cardNumber)) {
			return "";
		} else {
			return cardNumber.replaceAll(".(?=.{4})", "x");
		}
	}

	/** */
	final public static float calculatePoints(final Transaction sub) {
		float purchaseAmount = sub.getTransAmt();
		float upperLimit = 100;
		float lowerLimit = 50;
		float points = 0;
		// float addSum = 0;
		float purchaseSum = 0;
		final float purchaseAmountforTotal = sub.getTransAmt();

		while (purchaseAmount > lowerLimit) {
			final float rupeesAboveUppper = purchaseAmount - upperLimit;
			final float rupeesAboveLower = purchaseAmount - lowerLimit;

			if (rupeesAboveUppper > 0) {
				points += 2 * rupeesAboveUppper;
				purchaseAmount -= rupeesAboveUppper;
			} else if (rupeesAboveLower > 0) {
				points += 1 * rupeesAboveLower;
				purchaseAmount -= rupeesAboveLower;
			}
		}
		purchaseSum += purchaseAmountforTotal;

		return points;
	}

	/** */
	final public static float getTotalAmount(final Transaction sub) {
		final float purchaseAmountforTotal = sub.getTransAmt();
		// float addSum = 0;
		float purchaseSum = 0;

		purchaseSum += purchaseAmountforTotal;

		return purchaseSum;

	}

	/** */
	public static float calculateRewardPoints(final float points, final float purchaseAmount) {
		float upperLimit = 100;
		float lowerLimit = 50;

		float updatedPoints = points;
		float updatedPurchaseAmount = purchaseAmount;
		while (updatedPurchaseAmount > lowerLimit) {
			final float rupeesAboveUppper = updatedPurchaseAmount - upperLimit;
			final float rupeesAboveLower = updatedPurchaseAmount - lowerLimit;

			if (rupeesAboveUppper > 0) {
				updatedPoints += 2 * rupeesAboveUppper;
				updatedPurchaseAmount -= rupeesAboveUppper;
			} else if (rupeesAboveLower > 0) {
				updatedPoints += 1 * rupeesAboveLower;
				updatedPurchaseAmount -= rupeesAboveLower;
			}
		}
		return updatedPoints;
	}
}
