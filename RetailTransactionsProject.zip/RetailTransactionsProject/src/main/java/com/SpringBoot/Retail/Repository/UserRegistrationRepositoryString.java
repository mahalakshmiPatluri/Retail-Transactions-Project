package com.SpringBoot.Retail.Repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.SpringBoot.Retail.Entity.UserRegistration;
/** User Registration Repository*/
@Repository
public interface UserRegistrationRepositoryString extends CrudRepository<UserRegistration, String>{
	/** To find a user by email*/
	Optional<UserRegistration> findByEmail(String email);
	
	

}
