package com.SpringBoot.Retail.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.SpringBoot.Retail.Entity.UserRegistration;
import com.SpringBoot.Retail.Repository.UserRegistrationRepository;
import com.SpringBoot.Retail.Repository.UserRegistrationRepositoryString;

@Service
public class UserRegistrationService {
	UserRegistrationRepository userRepo;

	UserRegistrationRepositoryString userRepoString;

	public UserRegistrationService(UserRegistrationRepository userRepo,
			UserRegistrationRepositoryString userRepoString) {
		this.userRepo = userRepo;
		this.userRepoString = userRepoString;
	}

	public void save(UserRegistration userReg) {
		userRepo.save(userReg);
	}

	public UserRegistration getUserById2(String email) {
		return userRepoString.findByEmail(email).get();

	}

	public UserRegistration getUserById(long mobile) {
		return userRepo.findByMobile(mobile).get();

	}

	public UserRegistration getUserById1(long id) {
		return userRepo.findById(id).get();

	}

	public List<UserRegistration> getAllUsers() {
		List<UserRegistration> employees = new ArrayList<UserRegistration>();
		userRepo.findAll().forEach(userReg -> employees.add(userReg));
		return employees;
	}

	public void saveOrUpdate(UserRegistration userReg) {
		userRepo.save(userReg);
	}

	public void deleteUserById(int id) {
		userRepo.deleteById((long) id);
	}

}
