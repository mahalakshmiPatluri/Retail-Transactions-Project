package com.SpringBoot.Retail.Repository;

import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;

import com.SpringBoot.Retail.Entity.Transaction;
/** */
//@Repository
public interface TransactionRepositoryInteger extends CrudRepository<Transaction, Integer> {
/** */
	void deleteById(int transRefNo);

	
}
