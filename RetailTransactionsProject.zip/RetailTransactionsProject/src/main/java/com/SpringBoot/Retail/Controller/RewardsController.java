package com.SpringBoot.Retail.Controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.Retail.Entity.MonthlyData;
import com.SpringBoot.Retail.Entity.Rewards;
import com.SpringBoot.Retail.Entity.RewardsMonth;
import com.SpringBoot.Retail.Entity.Transaction;
import com.SpringBoot.Retail.Entity.UserRegistration;
import com.SpringBoot.Retail.Service.RewardsService;
import com.SpringBoot.Retail.Service.TransactionService;
import com.SpringBoot.Retail.Service.UserRegistrationService;
import com.SpringBoot.Retail.Utility.Utility;

@RestController
@RequestMapping(path = "/rewards")
/** */
public class RewardsController {
	int count = 0;
	private static final String TOTAL_TRANSACTIONS = "Total Transactions";
	private static final String TOTAL_REWARD_POINTS = "Total Reward Points";
	private static final String TOTAL_AMOUNT = "Total Amount";
	/** */
	RewardsService rewardsService;
	/** */
	UserRegistrationService userRegistrationService;

	TransactionService transactionService;

	/** */
	public RewardsController(final RewardsService rewardsService, final UserRegistrationService userRegistrationService,
			final TransactionService transactionService) {
		super();
		this.rewardsService = rewardsService;
		this.userRegistrationService = userRegistrationService;
		this.transactionService = transactionService;
	}

	/** */
	@GetMapping("/user/id/{id}")
	public Object getUserByID(@PathVariable("id") final long id) {
		final ArrayList<Transaction> arrayList = (ArrayList<Transaction>) transactionService.getAllTransactionDetails();
		float purchaseSum = 0;
		float addSum = 0;
		float points = 0;
		for (final Transaction data : arrayList) {

			final float purchaseAmount = data.getTransAmt();
			final float purchaseAmountforTotal = data.getTransAmt();
			points = Utility.calculateRewardPoints(points, purchaseAmount);
			purchaseSum += purchaseAmountforTotal;

		}
		count += points;
		addSum += purchaseSum;
		ResponseEntity<UserRegistrationFailureResponse> failureResponse = ResponseEntity.status(HttpStatus.OK)
				.body(new UserRegistrationFailureResponse(new Date(), 200, "User with this ID Number not available",
						"rewards/user/id"));
		try {
			final UserRegistration userDetails = userRegistrationService.getUserById1(id);
			final HashMap<String, Object> responseBody = new HashMap<String, Object>();
			responseBody.put("UserID", userDetails.getId());
			responseBody.put("UserName", userDetails.getUserName());
			responseBody.put("UserMobile", userDetails.getMobile());
			responseBody.put("UserEmail", userDetails.getEmail());
			responseBody.put("UserAddress", userDetails.getUserAddress());
			responseBody.put("TotalAmount", addSum);
			responseBody.put("TotalRewardPoints", points);
			return responseBody;
		}

		catch (Exception e) {
			return failureResponse;

		}
	}

	/** */

	@GetMapping("/user/mobile/{mobile}")
	public Object getUserByMobile(@PathVariable("mobile") final long mobile, final Transaction transaction) {

		final ArrayList<Transaction> arrayList = (ArrayList<Transaction>) transactionService.getAllTransactionDetails();
		float purchaseSum = 0;
		float addSum = 0;
		float points = 0;
		String cardNumber = null;

		for (final Transaction data : arrayList) {
			cardNumber = data.getCardNumber();
			final float purchaseAmount = data.getTransAmt();
			final float purchaseAmountforTotal = data.getTransAmt();

			points = Utility.calculateRewardPoints(points, purchaseAmount);
			purchaseSum += purchaseAmountforTotal;

		}
		count += points;
		addSum += purchaseSum;
		ResponseEntity<UserRegistrationFailureResponse> failureResponseforMobile = ResponseEntity.status(HttpStatus.OK)
				.body(new UserRegistrationFailureResponse(new Date(), 200, "User with this mobile number not available",
						"rewards/user/mobile"));
		try {
			final String maskedCardNumber = Utility.getMaskedCardNumber(cardNumber);
			final UserRegistration userDetails = userRegistrationService.getUserById(mobile);
			final HashMap<String, Object> responseBody = new HashMap<>();
			responseBody.put("UserID", userDetails.getId());
			responseBody.put("UserName", userDetails.getUserName());
			responseBody.put("UserMobile", userDetails.getMobile());
			responseBody.put("UserEmail", userDetails.getEmail());
			responseBody.put("UserAddress", userDetails.getUserAddress());
			responseBody.put("CardNumber", maskedCardNumber);
			responseBody.put("TotalAmount", addSum);
			responseBody.put("TotalRewardPoints", points);
			return responseBody;
		} catch (Exception e) {
			return failureResponseforMobile;
		}
	}

	@GetMapping("/user/email/{email}")
	public Object getUserByEmail(@PathVariable("email") String email) {
		ArrayList<Transaction> arrayList = (ArrayList<Transaction>) transactionService.getAllTransactionDetails();
		float purchaseSum = 0;
		float addSum = 0;
		float points = 0;
		for (final Transaction data : arrayList) {

			final float purchaseAmount = data.getTransAmt();
			final float purchaseAmountforTotal = data.getTransAmt();
			points = Utility.calculateRewardPoints(points, purchaseAmount);
			purchaseSum += purchaseAmountforTotal;

		}
		count += points;
		addSum += purchaseSum;

		ResponseEntity<UserRegistrationFailureResponse> failureResponseforEmail = ResponseEntity.status(HttpStatus.OK)
				.body(new UserRegistrationFailureResponse(new Date(), 200, "User with this Email ID not available",
						"rewards/user/mobile"));
		try {
			final UserRegistration userDetails = userRegistrationService.getUserById2(email);
			final Map<String, Object> responseBody = new HashMap<String, Object>();

			responseBody.put("UserID", userDetails.getId());
			responseBody.put("UserName", userDetails.getUserName());
			responseBody.put("UserMobile", userDetails.getMobile());
			responseBody.put("UserEmail", userDetails.getEmail());
			responseBody.put("UserAddress", userDetails.getUserAddress());
			responseBody.put("TotalAmount", addSum);
			responseBody.put("TotalRewardPoints", points);
			return responseBody;
		} catch (Exception e) {

			return failureResponseforEmail;
		}
	}

	@GetMapping("/monthlyReport/{id}")
	final public Map<String, Object> getTransaction(@PathVariable("id") final int id) {
		float janRewardPoints = 0;
		float janPoints = 0;
		float addSumJanuary = 0;
		float totalAmountJanuary = 0;

		float febRewardPoints = 0;
		float febPoints = 0;
		float addSumFebruary = 0;
		float totalAmountFebruary = 0;

		float aprilrewardPoints = 0;
		float aprilpoints = 0;
		float addSumApril = 0;
		float totalAmountApril = 0;

		float marchrewardPoints = 0;
		float marchpoints = 0;
		float addSumMarch = 0;
		float totalAmountMarch = 0;

		float mayRewardPoints = 0;
		float mayPoints = 0;
		float addSumMay = 0;
		float totalAmountMay = 0;

		float juneRewardPoints = 0;
		float junePoints = 0;
		float addSumJune = 0;
		float totalAmountJune = 0;

		float julyRewardPoints = 0;
		float julyPoints = 0;
		float addSumJuly = 0;
		float totalAmountJuly = 0;

		float augRewardPoints = 0;
		float augPoints = 0;
		float addSumAug = 0;
		float totalAmountAug = 0;

		float septRewardPoints = 0;
		float septPoints = 0;
		float addSumSept = 0;
		float totalAmountSept = 0;

		float octRewardPoints = 0;
		float octPoints = 0;
		float addSumOct = 0;
		float totalAmountOct = 0;

		float novRewardPoints = 0;
		float novPoints = 0;
		float addSumNov = 0;
		float totalAmountNov = 0;

		float decRewardPoints = 0;
		float decPoints = 0;
		float addSumDec = 0;
		float totalAmountDec = 0;

		int janTransCount = 0;
		int febTransCount = 0;
		int marchTransCount = 0;
		int aprilTransCount = 0;
		int mayTransCount = 0;
		int juneTransCount = 0;
		int julyTransCount = 0;
		int augustTransCount = 0;
		int septTransCount = 0;
		int octTransCount = 0;
		int novTransCount = 0;
		int decTransCount = 0;
		final List<Transaction> trans = transactionService.getUserById(id);
		String[] split;
		for (final Transaction data : trans) {

			// Date TransDate = data.getTransDate();
			Date monthValue = data.getTransDate();
			System.out.println("MONTHVALUE*****" + monthValue);

			String str = String.valueOf(monthValue);
			String subString = str.substring(5, 7);
			// System.out.println("DATE****" + TransDate);

			// split = data.getTransDate().split("-");

			// final String month = split[1];

			if (subString.equalsIgnoreCase("01")) {
				janTransCount = janTransCount + 1;
				janPoints += Utility.calculatePoints(data);
				janRewardPoints = janPoints;
				addSumJanuary += Utility.getTotalAmount(data);
				totalAmountJanuary = addSumJanuary;

			}

			if (subString.equalsIgnoreCase("02")) {
				febTransCount = febTransCount + 1;
				febPoints += Utility.calculatePoints(data);
				febRewardPoints = febPoints;
				addSumFebruary += Utility.getTotalAmount(data);
				totalAmountFebruary = addSumFebruary;
			}

			if (subString.equalsIgnoreCase("03")) {
				marchTransCount = marchTransCount + 1;
				marchpoints += Utility.calculatePoints(data);
				marchrewardPoints = marchpoints;
				addSumMarch += Utility.getTotalAmount(data);
				totalAmountMarch = addSumMarch;
			}

			if (subString.equalsIgnoreCase("04")) {
				aprilTransCount = aprilTransCount + 1;
				aprilpoints += Utility.calculatePoints(data);
				aprilrewardPoints = aprilpoints;
				addSumApril += Utility.getTotalAmount(data);
				totalAmountApril = addSumApril;
			}

			if (subString.equalsIgnoreCase("05")) {
				mayTransCount = mayTransCount + 1;
				mayPoints += Utility.calculatePoints(data);
				mayRewardPoints = mayPoints;
				addSumMay += Utility.getTotalAmount(data);
				totalAmountMay = addSumMay;
			}
			if (subString.equalsIgnoreCase("06")) {
				juneTransCount = juneTransCount + 1;
				junePoints += Utility.calculatePoints(data);
				juneRewardPoints = junePoints;
				addSumJune += Utility.getTotalAmount(data);
				totalAmountJune = addSumJune;
			}
			if (subString.equalsIgnoreCase("07")) {
				julyTransCount = julyTransCount + 1;
				julyPoints += Utility.calculatePoints(data);
				julyRewardPoints = julyPoints;
				addSumJuly += Utility.getTotalAmount(data);
				totalAmountJuly = addSumJuly;
			}
			if (subString.equalsIgnoreCase("08")) {
				augustTransCount = augustTransCount + 1;
				augPoints += Utility.calculatePoints(data);
				augRewardPoints = augPoints;
				addSumAug += Utility.getTotalAmount(data);
				totalAmountAug = addSumAug;
			}
			if (subString.equalsIgnoreCase("09")) {
				septTransCount = septTransCount + 1;
				septPoints += Utility.calculatePoints(data);
				septRewardPoints = septPoints;
				addSumSept += Utility.getTotalAmount(data);
				totalAmountSept = addSumSept;
			}
			if (subString.equalsIgnoreCase("10")) {
				octTransCount = octTransCount + 1;
				octPoints += Utility.calculatePoints(data);
				octRewardPoints = octPoints;
				addSumOct += Utility.getTotalAmount(data);
				totalAmountOct = addSumOct;
			}
			if (subString.equalsIgnoreCase("11")) {
				novTransCount = novTransCount + 1;
				novPoints += Utility.calculatePoints(data);
				novRewardPoints = novPoints;
				addSumNov += Utility.getTotalAmount(data);
				totalAmountNov = addSumNov;
			}
			if (subString.equalsIgnoreCase("12")) {
				decTransCount = decTransCount + 1;
				decPoints += Utility.calculatePoints(data);
				decRewardPoints = decPoints;
				addSumDec += Utility.getTotalAmount(data);
				totalAmountDec = addSumDec;
			}

		}

		final HashMap<String, Object> responseBody = new HashMap<>();

		final HashMap<String, Object> januaryRecords = new HashMap<>();
		januaryRecords.put(TOTAL_AMOUNT, totalAmountJanuary);
		januaryRecords.put(TOTAL_REWARD_POINTS, janRewardPoints);
		januaryRecords.put(TOTAL_TRANSACTIONS, janTransCount);

		final HashMap<String, Object> februaryRecords = new HashMap<>();
		februaryRecords.put(TOTAL_AMOUNT, totalAmountFebruary);
		februaryRecords.put(TOTAL_REWARD_POINTS, febRewardPoints);
		februaryRecords.put(TOTAL_TRANSACTIONS, febTransCount);

		final HashMap<String, Object> marchRecords = new HashMap<>();
		marchRecords.put(TOTAL_AMOUNT, totalAmountMarch);
		marchRecords.put(TOTAL_REWARD_POINTS, marchrewardPoints);
		marchRecords.put(TOTAL_TRANSACTIONS, marchTransCount);

		final HashMap<String, Object> aprilRecords = new HashMap<>();
		aprilRecords.put(TOTAL_AMOUNT, totalAmountApril);
		aprilRecords.put(TOTAL_REWARD_POINTS, aprilrewardPoints);
		aprilRecords.put(TOTAL_TRANSACTIONS, aprilTransCount);

		final HashMap<String, Object> mayRecords = new HashMap<>();
		mayRecords.put(TOTAL_AMOUNT, totalAmountMay);
		mayRecords.put(TOTAL_REWARD_POINTS, mayRewardPoints);
		mayRecords.put(TOTAL_TRANSACTIONS, mayTransCount);

		final HashMap<String, Object> juneRecords = new HashMap<>();
		juneRecords.put(TOTAL_AMOUNT, totalAmountJune);
		juneRecords.put(TOTAL_REWARD_POINTS, juneRewardPoints);
		juneRecords.put(TOTAL_TRANSACTIONS, juneTransCount);

		final HashMap<String, Object> julyRecords = new HashMap<>();
		julyRecords.put(TOTAL_AMOUNT, totalAmountJuly);
		julyRecords.put(TOTAL_REWARD_POINTS, julyRewardPoints);
		julyRecords.put(TOTAL_TRANSACTIONS, julyTransCount);

		final HashMap<String, Object> augRecords = new HashMap<>();
		augRecords.put(TOTAL_AMOUNT, totalAmountAug);
		augRecords.put(TOTAL_REWARD_POINTS, augRewardPoints);
		augRecords.put(TOTAL_TRANSACTIONS, augustTransCount);

		final HashMap<String, Object> septRecords = new HashMap<>();
		septRecords.put(TOTAL_AMOUNT, totalAmountSept);
		septRecords.put(TOTAL_REWARD_POINTS, septRewardPoints);
		septRecords.put(TOTAL_TRANSACTIONS, septTransCount);

		final HashMap<String, Object> octRecords = new HashMap<>();
		octRecords.put(TOTAL_AMOUNT, totalAmountOct);
		octRecords.put(TOTAL_REWARD_POINTS, octRewardPoints);
		octRecords.put(TOTAL_TRANSACTIONS, octTransCount);

		final HashMap<String, Object> novRecords = new HashMap<>();
		novRecords.put(TOTAL_AMOUNT, totalAmountNov);
		novRecords.put(TOTAL_REWARD_POINTS, novRewardPoints);
		novRecords.put(TOTAL_TRANSACTIONS, novTransCount);

		final HashMap<String, Object> decRecords = new HashMap<>();
		decRecords.put(TOTAL_AMOUNT, totalAmountDec);
		decRecords.put(TOTAL_REWARD_POINTS, decRewardPoints);
		decRecords.put(TOTAL_TRANSACTIONS, decTransCount);

		responseBody.put("January", januaryRecords);
		responseBody.put("February", februaryRecords);
		responseBody.put("March", marchRecords);
		responseBody.put("April", aprilRecords);
		responseBody.put("May", mayRecords);
		responseBody.put("June", juneRecords);
		responseBody.put("July", julyRecords);
		responseBody.put("August", augRecords);
		responseBody.put("September", septRecords);
		responseBody.put("October", octRecords);
		responseBody.put("November", novRecords);
		responseBody.put("December", decRecords);

		return responseBody;
	}

	@GetMapping("/monthly/{id}")
	public Map<List<MonthlyData>, MonthlyData> getUser(@PathVariable("id") int id) {

		return rewardsService.getUsersById(id);

	}
}
